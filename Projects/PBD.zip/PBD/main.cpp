#include <iostream>
#include "particles.h"

int main(int argc, char* argv[])
{

	Particles<float> * temp = new Particles<float>();

	// Particles<float>::createFromObj("Fidget_Spinner.obj");
	temp->createFromObj("Fidget_Spinner.obj");
	std::cout << "!!!" << std::endl;
	return 0;
}

